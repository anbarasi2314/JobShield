/* ==========================================================================
   JobShield — Analysis Engine (Phase 1-3 demo implementation)

   This is a transparent, client-side, KEYWORD/HEURISTIC based scoring
   engine — it is a stand-in for the real AI-assisted backend described in
   the project's later phases (see README.md, Phase 5). It exists so the
   full frontend flow — submit, process, score, explain, recommend, save —
   is genuinely functional for demos, without requiring a live AI API key
   or backend deployment. Swap `runAnalysis()`'s internals for a real
   backend call and every screen downstream keeps working unchanged.
   ========================================================================== */

const JobShieldEngine = (() => {

  // Each rule: id, label, category, weight, matcher(text) -> bool, explain(text)
  const RULES = [
    {
      id: 'payment',
      name: 'Payment Request',
      weight: 30,
      test: t => /(registration fee|processing fee|security deposit|refundable deposit|pay.{0,15}(to (start|join|secure)|before you start)|advance payment|training fee|kit fee|joining fee)/i.test(t),
      text: 'The posting asks applicants to pay a fee — registration, training, deposit, or similar — before or during hiring.',
      recoLow: null,
    },
    {
      id: 'salary',
      name: 'Salary Claim',
      weight: 18,
      test: t => /(₹\s?[5-9]\d,?\d{3,}\s?\/?\s?(day|week)|\$\s?\d{3,}\s?\/?\s?(day|week)|earn.{0,20}(daily|weekly|per day)|guaranteed income|no experience.{0,25}(high pay|high salary|lakh))/i.test(t),
      text: 'The advertised compensation looks unusually high relative to the stated role, experience level, or working hours.',
    },
    {
      id: 'contact',
      name: 'Contact Information',
      weight: 14,
      test: t => /(whatsapp only|contact.{0,15}on whatsapp|@gmail\.com|@yahoo\.com|@hotmail\.com|telegram (only|group)|no official email)/i.test(t),
      text: 'Contact is routed through a free personal email domain or a messaging app instead of an official company channel.',
    },
    {
      id: 'urgency',
      name: 'Urgency & Pressure',
      weight: 16,
      test: t => /(limited (seats|slots)|act now|apply immediately|only \d+ (spots|seats|positions) left|urgent(ly)? (hiring|required)|hurry|offer expires|today only|immediate joining)/i.test(t),
      text: 'The posting uses pressure-based language pushing applicants toward an immediate decision, which limits time to verify details.',
    },
    {
      id: 'personal-info',
      name: 'Sensitive Data Requests',
      weight: 20,
      test: t => /(bank account (number|details)|aadhaar|passport number|otp|credit card|debit card|upi pin|ifsc code|social security)/i.test(t),
      text: 'The posting or process requests sensitive personal or financial information earlier than a legitimate hiring process typically requires.',
    },
    {
      id: 'links',
      name: 'External / Unofficial Links',
      weight: 10,
      test: t => /(bit\.ly|tinyurl|shorturl|forms\.gle\/[a-z0-9]|click here to (register|verify|claim))/i.test(t),
      text: 'The posting relies on a shortened or generic form link rather than an official company domain.',
    },
    {
      id: 'company-info',
      name: 'Missing Company Details',
      weight: 15,
      test: t => !/(pvt\.?\s?ltd|private limited|inc\.|llc|technologies|solutions|systems|corp|company name|www\.[a-z0-9-]+\.[a-z]{2,})/i.test(t),
      text: 'Important employer information — a registered name, an official website, or a verifiable address — is not clearly provided.',
    },
    {
      id: 'process',
      name: 'Unusual Hiring Process',
      weight: 12,
      test: t => /(no interview|interview.{0,15}chat only|hired instantly|no resume (needed|required)|selected without interview)/i.test(t),
      text: 'The hiring process skips standard steps such as a resume review or interview, which is uncommon for a genuine role.',
    },
  ];

  const BASE_NOISE = 4; // small baseline so a totally clean text isn't a hard 0

  function classify(score) {
    if (score >= 70) return { level: 'HIGH RISK', tone: 'high', emoji: '🚨' };
    if (score >= 45) return { level: 'ELEVATED RISK', tone: 'elevated', emoji: '⚠️' };
    if (score >= 20) return { level: 'MEDIUM RISK', tone: 'medium', emoji: '!' };
    return { level: 'LOW RISK', tone: 'low', emoji: '✓' };
  }

  function extractJobInfo(text) {
    const info = { title: null, company: null, location: null, salary: null, experience: null };

    const titleMatch = text.match(/(?:position|role|job title|hiring for)\s*[:\-]\s*([A-Za-z0-9 &/\-]{3,60})/i)
      || text.match(/^([A-Z][A-Za-z0-9 &/\-]{3,55}(?:intern(?:ship)?|developer|engineer|analyst|designer|executive|associate|manager))/m);
    if (titleMatch) info.title = titleMatch[1].trim();

    const companyMatch = text.match(/(?:company|organization|organisation|employer)\s*[:\-]\s*([A-Za-z0-9 &.,'\-]{2,50})/i)
      || text.match(/([A-Z][A-Za-z]+(?:\s[A-Z][A-Za-z]+)*\s(?:Technologies|Solutions|Systems|Pvt\.?\s?Ltd\.?|Inc\.?|LLC|Corp\.?))/);
    if (companyMatch) info.company = companyMatch[1].trim();

    const locMatch = text.match(/(?:location|based in|work from)\s*[:\-]\s*([A-Za-z ,]{2,40})/i) || text.match(/\b(remote|work from home|wfh)\b/i);
    if (locMatch) info.location = (locMatch[1] || locMatch[0]).trim();

    const salaryMatch = text.match(/(₹\s?[\d,]+\s?(?:\/|per)?\s?(?:month|day|week|annum|year)?)/i) || text.match(/(\$\s?[\d,]+\s?(?:\/|per)?\s?(?:month|hour|week|year)?)/i);
    if (salaryMatch) info.salary = salaryMatch[1].trim();

    const expMatch = text.match(/(fresher|no experience|\d+\+?\s?years?\s?(?:of)?\s?experience|entry.level)/i);
    if (expMatch) info.experience = expMatch[1].trim();

    return info;
  }

  /**
   * Run the heuristic scan over a body of text (from paste, URL-derived
   * content, or OCR/typed-fallback text from an image).
   */
  function scoreText(text) {
    const t = (text || '').toLowerCase();
    const factors = [];
    let raw = BASE_NOISE;

    RULES.forEach(rule => {
      if (rule.test(t)) {
        raw += rule.weight;
        factors.push({
          id: rule.id,
          name: rule.name,
          weight: rule.weight,
          text: rule.text,
        });
      }
    });

    const score = Math.max(0, Math.min(100, Math.round(raw)));
    const { level, tone, emoji } = classify(score);

    // Rank factors by weight for display severity, cap at 6 shown
    factors.sort((a, b) => b.weight - a.weight);
    const factorsOut = factors.slice(0, 6).map(f => ({
      ...f,
      severity: f.weight >= 20 ? 'high' : f.weight >= 13 ? 'elevated' : 'medium',
    }));

    return {
      score,
      level,
      tone,
      emoji,
      factors: factorsOut,
      jobInfo: extractJobInfo(text || ''),
      analyzedAt: new Date().toISOString(),
    };
  }

  function scoreUrl(url) {
    let signal = '';
    try {
      const u = new URL(/^https?:\/\//i.test(url) ? url : `https://${url}`);
      if (u.protocol !== 'https:') signal += ' not-https ';
      if (/bit\.ly|tinyurl|shorturl|is\.gd/i.test(u.hostname)) signal += ' click here to verify shortened link ';
      if (/\d{3,}/.test(u.hostname) || /-jobs?-|-hiring-|freegift/i.test(u.hostname)) signal += ' limited seats urgent ';
      if (!/\.(com|org|in|net|co)$/i.test(u.hostname)) signal += ' missing company details ';
    } catch (e) {
      signal = 'missing company details';
    }
    // URL path alone rarely contains full context — blend with a mild baseline
    const result = scoreText(signal);
    result.jobInfo.source = url;
    return result;
  }

  function recommendations(tone) {
    if (tone === 'high' || tone === 'elevated') {
      return [
        'Do not pay any registration, training, or "refundable" deposit fees.',
        'Verify the company independently through its official website and registered address.',
        'Confirm the recruiter is using an official company email domain, not a free provider.',
        'Avoid sharing bank details, ID numbers, or OTPs during early hiring stages.',
        'Cross-check the posting on trusted job platforms before responding further.',
      ];
    }
    return [
      'Still verify the employer independently, even for lower-risk postings.',
      'Check the official company website and look for an "About" or careers page.',
      'Confirm the recruiter\'s identity and role before an interview.',
      'Avoid sharing sensitive personal information unless the process clearly requires it.',
    ];
  }

  return { scoreText, scoreUrl, recommendations, classify };
})();

/* ---------------------------------- History store ---------------------------------- */

const JobShieldHistory = (() => {
  const KEY = 'jobshield_history_v1';

  function all() {
    try { return JSON.parse(localStorage.getItem(KEY)) || []; }
    catch (e) { return []; }
  }

  function save(entry) {
    const list = all();
    list.unshift(entry);
    localStorage.setItem(KEY, JSON.stringify(list.slice(0, 100)));
  }

  function clear() { localStorage.removeItem(KEY); }

  return { all, save, clear };
})();
